from .tour import places_for_category_router
from .schedule import tickets_router
from .closest import closest_router
