from sqlalchemy import Column, Integer, String, Boolean, DateTime
from sqlalchemy.ext.declarative import declarative_base

Base = declarative_base()

class UserModel(Base):
    __tablename__ = 'users'

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(length=50), index=True, nullable=False)
    surname = Column(String(length=50), index=True, nullable=True)
    phone = Column(String(length=15), index=True, nullable=True)
    birth_date = Column(DateTime, index=True, nullable=True)
    gender = Column(String(length=10), index=True, nullable=True)  # Используйте String для выбора пола
    disabled = Column(Boolean, index=True, default=False)  # Добавьте значение по умолчанию, если это имеет смысл
